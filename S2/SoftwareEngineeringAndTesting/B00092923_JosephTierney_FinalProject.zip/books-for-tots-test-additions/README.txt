DATABASE INSTALLATION

MYSQL

schema: booksfortots
user: root
password:

SQL provided

GITHub:
https://github.com/dihn/books-for-tots