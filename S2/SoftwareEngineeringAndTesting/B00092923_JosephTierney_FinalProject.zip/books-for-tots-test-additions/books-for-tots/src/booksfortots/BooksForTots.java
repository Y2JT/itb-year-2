package booksfortots;

import javax.swing.JFrame;

public class BooksForTots {

	public static void main(String[] args) {
		Login login = new Login();
		login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
