package BooksForTots;

import javax.swing.JFrame;

public class BooksForTots {

	public static void main(String[] args) {
		BooksForTotsGUI gui = new BooksForTotsGUI();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
